<?php include('header.php')?>		 
<div class="container-fluid">
   <!-- DataTables Example -->
   <div class="card mb-3">
	  <div class="card-header">
		 <i class="fa fa-fw fa-user"></i>
		 Customer Table
	  </div>
	  <div class="card-body">
		 <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
			   <thead>
				  <tr>
					 <th>Name</th>
					 <th>City</th>
					 <th>Email</th>
					 

				  </tr>
			   </thead>
			   
			   <tbody>
				  <tr>
					 <td>Humza</td>
					 <td>Lahore</td>
					 <td>humza@gmail.com</td>
					 
				  </tr>
				  <tr>
					 <td>Furqan</td>
					 <td>Islamabad</td>
					 <td>Furqan@gmail.com</td>
					 
				  </tr>
			   </tbody>
			</table>
		 </div>
	  </div>
   </div>
</div>
</div>
<!-- /.container-fluid -->
<?php include('footer.php')?>