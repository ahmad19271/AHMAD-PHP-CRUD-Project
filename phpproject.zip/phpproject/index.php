<?php 
include('header.php');
if(isset($_SESSION['ROLE']) && $_SESSION['ROLE']!='1'){
	header('location:customer.php');
	die();
}
?>
<div class="container-fluid">
<ol class="breadcrumb">
  <li class="breadcrumb-item">
	 <a href="">Dashboard</a>
  </li>
</ol>
<!-- Page Content -->
<h1>Admin Page</h1>
<hr>
<h2>Please go to employee and customer for more information.</h2>
</div>
<?php include('footer.php')?>