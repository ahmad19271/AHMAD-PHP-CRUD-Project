$(document).ready(function() {
    getAllEmployee();

    function getAllEmployee() {
        $.ajax({
            url: "getAllEmployee.php",
            method: "POST",
            dataType: "json",
            success: function(res) {
                console.log(res); // Log the response from getAllEmployee.php
                if (res && res.userdata) {
                    getUser(res.userdata);
                } else {
                    console.error("Unexpected response format:", res);
                }
            },
            error: function(xhr, status, error) {
                console.error("Error fetching employees:", status, error);
            }
        });
    }

    function getUser(response) {
        console.log(response); // Log the data to be populated in the table
        var data = "";
        $.each(response, function(index, value) {
            data += "<tr>";
            data += "<td>" + value.id + "</td>";
            data += "<td>" + value.name + "</td>";
            data += "<td>" + value.emailid + "</td>";
            data += "<td>" + value.password + "</td>";
            data += "<td>" + value.company_name + "</td>";
            data += "</tr>";
        });
        $("tbody").html(data);
    }

    $('#btnAddEmployee').click(function() {
        $.ajax({
            url: "addemployee.php",
            method: "POST",
            data: $("#frm").serialize(),
            success: function(res) {
                console.log(res); // Log the response from addemployee.php
                toastr.success(res, 'Success', { timeOut: 3000 });
                getAllEmployee();
                $('#myModal').modal('hide');
            },
            error: function(xhr, status, error) {
                console.error("Error adding employee:", status, error);
                toastr.error("Error adding employee: " + error, 'Error', { timeOut: 3000 });
            }
        });
    });
});