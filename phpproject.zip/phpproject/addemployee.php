<?php
include_once "config.php";
$name = $_POST["txtName"];
$eid = $_POST["txtEid"];
$password = $_POST["txtPass"];
$cnm = $_POST["txtCmpName"];
$q = mysqli_query($conn, "INSERT INTO employee_user_(name, emailid, password, company_name) VALUE('$name', '$eid', '$password', '$cnm')");
if ($q) {
    echo "Employee added successfully";
} else {
    echo "Error adding employee: " . mysqli_error($conn);
}
?>
