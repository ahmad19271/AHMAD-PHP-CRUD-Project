<?php 
include('header.php');
if(isset($_SESSION['ROLE']) && $_SESSION['ROLE']!='1'){
	header('location:customer.php');
	die();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Management</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Employee Management</h1>
        <button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add Employee</button>
        <table class="table mt-3">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>EmailId</th>
                    <th>Password</th>
                    <th>Company Name</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Employee</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <form id="frm">
                        <div class="form-group">
                            <label for="txtName">Enter Name</label>
                            <input type="text" class="form-control" id="txtName" name="txtName" required>
                        </div>
                        <div class="form-group">
                            <label for="txtEid">Enter Email ID</label>
                            <input type="email" class="form-control" id="txtEid" name="txtEid" required>
                        </div>
                        <div class="form-group">
                            <label for="txtPass">Enter Password</label>
                            <input type="password" class="form-control" id="txtPass" name="txtPass" required>
                        </div>
                        <div class="form-group">
                            <label for="txtCmpName">Enter Company</label>
                            <input type="text" class="form-control" id="txtCmpName" name="txtCmpName" required>
                        </div>
                        <button type="button" id="btnAddEmployee" class="btn btn-primary">Add employee</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/toastr@latest/toastr.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="crud.js"></script>
</body>
</html>
<?php include('footer.php')?>